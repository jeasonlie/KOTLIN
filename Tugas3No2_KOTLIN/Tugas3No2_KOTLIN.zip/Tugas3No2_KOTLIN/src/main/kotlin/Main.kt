fun main(args: Array<String>) {
    val lingkaran = Circle(5.0)

    println("Luas Lingkaran: ${lingkaran.calculateArea()}")
    println("Keliling Lingkaran: ${lingkaran.calculatePerimeter()}")
}