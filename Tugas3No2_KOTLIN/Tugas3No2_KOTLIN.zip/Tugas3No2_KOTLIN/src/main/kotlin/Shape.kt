interface Shape {
    fun calculateArea(): Double
    fun calculatePerimeter(): Double
}